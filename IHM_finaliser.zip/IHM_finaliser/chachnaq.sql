-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 23 avr. 2021 à 03:30
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `chachnaq`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `idAdmin` int(11) NOT NULL AUTO_INCREMENT,
  `nomAdmin` varchar(30) NOT NULL,
  `motDePasse` varchar(30) NOT NULL,
  PRIMARY KEY (`idAdmin`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`idAdmin`, `nomAdmin`, `motDePasse`) VALUES
(1, 'admin', 'admin'),
(2, 'boukhari', 'redha'),
(6, 'zaky', 'smail'),
(4, 'amayas', 'amir'),
(5, 'ahmed', 'maloum');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `idCategorie` int(11) NOT NULL AUTO_INCREMENT,
  `nomCategorie` varchar(30) NOT NULL,
  `nbrProduit` int(100) NOT NULL,
  PRIMARY KEY (`idCategorie`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `idclient` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `Dnaiss` varchar(10) NOT NULL,
  `telephone` varchar(10) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`idclient`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`idclient`, `nom`, `prenom`, `Dnaiss`, `telephone`, `mail`, `password`) VALUES
(42, 'ok', 'sfo', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123'),
(41, 'sdfsggsg', 'sfgsgg', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123'),
(40, 'sdfsggsg', 'sfgsgg', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123'),
(39, 'vogue', 'qs', '2003-01-01', '1234567890', 'oukhari@gmail.com', '123'),
(38, 'vogue', 'qs', '2003-01-01', '1234567890', 'oukhari@gmail.com', '123'),
(37, 'teste', 'final', '2000-11-07', '0559627327', 'rb73103@gmail.com', '1234'),
(36, 'teste', 'final', '2000-11-07', '0559627327', 'rb73103@gmail.com', '1234'),
(35, 'teste', 'final', '2000-11-07', '0559627327', 'rb73103@gmail.com', '1234'),
(34, 'vogue', 'qs', '2003-01-01', '1234567890', 'test@gmail.com', '123'),
(33, 'vogue', 'qs', '2003-01-01', '1234567890', 'test@gmail.com', '123'),
(43, 'ok', 'sfo', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123'),
(44, 'ahmed', 'maloum', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123'),
(45, 'ahmed', 'maloum', '1998-02-27', '1234567890', 'boui@gmail.com', '123'),
(46, 'wfdgfdag', 'gadsfv', '2003-01-01', '1234567890', 'boukhai@gmail.com', '123');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `idMessage` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `Options` varchar(100) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`idMessage`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`idMessage`, `nom`, `prenom`, `mail`, `Options`, `message`) VALUES
(1, '', '', '', 'Array', 'Array'),
(2, '', '', '', 'Array', 'Array'),
(3, '', '', '', 'Array', 'Array'),
(4, '', '', '', 'Array', 'Array'),
(5, '', '', '', 'Array', 'Array'),
(6, 'sdfsggsg', 'sfgsgg', 'boui@gmail.com', 'Array', ''),
(7, '', '', '', 'Array', 'Array'),
(8, '', '', '', 'Array', 'Array'),
(9, '', '', '', 'Array', 'Array'),
(10, 'sdfsggsg', 'bou', 'boukhari@gmail.com', 'Array', 'Array'),
(11, '', '', '', 'Array', 'Array'),
(12, 'vogue', 'sfgsgg', 'boukhai@gmail.com', 'info', ''),
(13, '', '', '', 'defaut', ''),
(14, '', '', '', 'defaut', 'ewfasdzbvc');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `idproduit` int(11) NOT NULL AUTO_INCREMENT,
  `nomProduit` varchar(30) NOT NULL,
  `Categorie` varchar(30) NOT NULL,
  `prix` int(10) NOT NULL,
  PRIMARY KEY (`idproduit`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`idproduit`, `nomProduit`, `Categorie`, `prix`) VALUES
(25, 'salade italienne', 'salade', 400);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contact`
--
ALTER TABLE `contact` ADD FULLTEXT KEY `message` (`message`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
