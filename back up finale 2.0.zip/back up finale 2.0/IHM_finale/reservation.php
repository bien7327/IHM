<html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <link type="text/css" rel="stylesheet" href="./css/header.css">
        <link rel="stylesheet" href="./css/reservation.css" media="screen" type="text/css" />
    </head>
    <body>

    <div class="heder" style="position: sticky;">


            <div class="logo select">
                <a href="./index.php #acceuil"><img src="./images/logo2.png" alt=""> </a>
            </div>
            <div class="nav_bar">
                <a href="./index.php #acceuil"class="nav3 select"> <ul > Acceuil </ul></a>
                <a href="#"class="nav0 select"><ul >La carte</ul> </a>
                <a href="#"class="nav1 select"><ul >Reserver</ul> </a>
                <a href="./index.php #contact"class="nav2 select"><ul >Contact</ul> </a>

            </div>
            <div class="co_insc">
                <a href="./connection_user.php" class="se_connecter select"><h1>Se connecter</h1></a>
                <a href="./Inscription.php" class="s_inscrire select"><h1>S'inscrire</h1></a>
            </div>
        </div>
        <div id="container">
            <!-- zone de connexion -->
            
            <form action="verification.php" method="POST">
                <h1>Connexion</h1>
                
                <div class="champ">
                    <input type="date" placeholder="Date de reservation" name="jour" required>
                    <input type="time" placeholder="Heure" name="heur" required>
                    <select class="nbpersonne">
                        <option value="p1">Pour 1 Personne</option>
                        <option value="p2" selected>Pour 4 Personne</option>
                    </select>
                    <select class="Table">
                        <option value="t1">Table Pour 2 Personne</option>
                        <option value="t2" selected>Table Pour 4 Personne</option>
                    </select>
                </div>
                <div class="btns">
                    <input type="submit" id='submit' value='Confirmer' class="confirmer">
                    <input type="submit" id='submit' value='Annuler'>
                </div>
            </form>
        </div>
    </body>
</html>