<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link type="text/css" rel="stylesheet" href="./css/inscription.css">
    <link type="text/css" rel="stylesheet" href="./css/header.css">
    <link type="text/css" rel="stylesheet" href="./css/alert.css">


</head>

<body>
    <div class="page">

    <div class="heder">


<div class="logo select">
    <a href="./index.php #acceuil"><img src="./images/logo2.png" alt=""> </a>
</div>
<div class="nav_bar">
    <a href="./index.php #acceuil"class="nav3 select"> <ul > Acceuil </ul></a>
    <a href="carte.php"class="nav0 select"><ul >La carte</ul> </a>
    <a href="#"class="nav1 select"><ul >Reserver</ul> </a>
    <a href="./index.php #contact"class="nav2 select"><ul >Contact</ul> </a>

</div>
<div class="co_insc">
    <a href="./connection_user.php" class="se_connecter select"><h1>Se connecter</h1></a>
    <a href="./Inscription.php" class="s_inscrire select"><h1>S'inscrire</h1></a>
</div>
</div>
        <div class="body">
            <!-- formulaire d'insription -->
                       
                <div class="formulaire">
                    <a href="reservation_med.php" ><div class="close_">+</div> </a>
                    <form action='reserver.php' method="POST">
    
                        <div class="modif">
                            <div class="nomProduit">
                                <label for="fname">Nom de produit:</label>
                                <input type="date" name="nomProduit" value="" id="nom" size="30" placeholder="Choisisser la date" minlength="3" required>
                            </div>

                            <div class="Categorie">
                                <label for="fname">Categorie du produit:</label> 
                                <!-- Recuperation des categorie de la base de donner --> 
                                <?php   $conn = new mysqli("localhost", "root", '', "chachnaq") or die(mysqli_error($conn)) ;
                                        $result =   $conn -> query( "SELECT * FROM categorie")or die(mysqli_error($conn)) ;
                                    ?>
                                <select id="categorie" name="Categorie">
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <option id='par_def' value="<?php echo $row['nomCategorie']; ?>"><?php echo $row['nomCategorie']; ?></option>
                                    <?php endwhile ;?>
                                </select>  
                            </div>
                            <div class="">
                                <label for="fname">Description du produit:</label>    
                                <input type="text" name="description" value="<?php echo $description ; ?>" id="description" size="27" placeholder="Descriprion du produit" required>
                            </div>
                
                            <div class="prix">
                                <label for="fname">Prix du produit:</label>
                                <input type="text" name="prix" id="prix" value="<?php echo $prix_; ?>" size="27" placeholder="Prix du produit" required>
                            </div>
                            <div class="image">
                                <label for="fname">Choisir une Image:</label>
                                <input id="prodId" name="image_" type="hidden" value="<?php echo $image_; ?>" >
                                <input type="file" accept="image/*" name="image" id="image" value="<?php echo $image_; ?>" size="27" placeholder="Choisire une image" >
                            </div>
                        </div>


                        <div class="bt">
                            <h1 class="titre_">Reserver</h1>
                            <input type="submit" name="submit" value="submit_table_reservation_form" class="button">
                           
                        </div>

                    </form>

                </div>
            </div>
            <?php endif ?>

</body>

</html>